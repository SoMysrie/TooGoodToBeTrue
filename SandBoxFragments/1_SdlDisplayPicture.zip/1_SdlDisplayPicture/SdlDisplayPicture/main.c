#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL_image.h>
#include "header.h"

int main(int argc, char *argv[])
{
    SDL_Surface *ecran = NULL, *imageDeFond = NULL;
    SDL_Rect positionFond;
    SDL_Surface *IMG_Load(const char *file);

    positionFond.x = 0;
    positionFond.y = 0;

    if (SDL_Init(SDL_INIT_VIDEO) == -1) // D�marrage de la SDL. Si erreur :
    {
        fprintf(stderr, "Erreur d'initialisation de la SDL : %s\n", SDL_GetError()); // �criture de l'erreur
        exit(EXIT_FAILURE); // On quitte le programme
    }

    ecran = SDL_SetVideoMode(1200, 900, 32, SDL_HWSURFACE);
    if (ecran == NULL) // Si l'ouverture a �chou�, on le note et on arr�te
    {
        fprintf(stderr, "Impossible de charger le mode vid�o : %s\n", SDL_GetError());
        exit(EXIT_FAILURE);
    }
    SDL_WM_SetCaption("Desktop", NULL);
    imageDeFond = IMG_Load("Resources/desktop.png");
    SDL_BlitSurface(imageDeFond, NULL, ecran, &positionFond);

    SDL_Flip(ecran); /* Mise � jour de l'�cran avec sa nouvelle couleur */
    pause();

    SDL_FreeSurface(imageDeFond); /* On lib�re la surface */
    SDL_Quit(); // Arr�t de la SDL (lib�ration de la m�moire).

    return 0;
}
