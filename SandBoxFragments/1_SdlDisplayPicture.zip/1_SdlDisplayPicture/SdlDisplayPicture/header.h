#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>

#include "SdlDisplayPicture.h"

#endif // HEADER_H_INCLUDED
