void input(char *phrase,char chaine[],int taille);
int inputInt(char *phrase,int *nb);
